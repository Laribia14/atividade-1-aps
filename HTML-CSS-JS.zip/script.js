document.getElementById('fetchDataBtn').addEventListener('click', fetchData);

function fetchData() {
    fetch('https://jsonplaceholder.typicode.com/posts')
        .then(response => response.json())
        .then(data => {
            const dataList = document.getElementById('dataList');
            dataList.innerHTML = ''; // Limpa a lista antes de adicionar novos itens

            data.forEach(item => {
                const li = document.createElement('li');
                li.textContent = `Título: ${item.title}`;
                dataList.appendChild(li);
            });
        })
        .catch(error => console.error('Erro ao buscar dados:', error));
}
